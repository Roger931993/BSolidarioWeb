import { IndexCuentasComponent } from "./index-cuentas.component";

describe("IndexCuentasComponent", () => {
  it("should mount", () => {
    cy.mount(IndexCuentasComponent);
  });
});
